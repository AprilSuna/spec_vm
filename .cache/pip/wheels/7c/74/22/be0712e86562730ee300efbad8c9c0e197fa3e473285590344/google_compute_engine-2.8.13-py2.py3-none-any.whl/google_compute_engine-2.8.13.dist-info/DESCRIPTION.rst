Google Compute Engine guest environment.


